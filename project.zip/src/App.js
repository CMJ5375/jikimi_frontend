import './App.css';
import KakaoMap from './component/KakaoMap';

function App() {
  
  return (
    <>
    <KakaoMap />
    </>
  );
}

export default App;
